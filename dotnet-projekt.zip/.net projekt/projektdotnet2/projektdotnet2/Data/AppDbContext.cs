﻿using Microsoft.EntityFrameworkCore;
using projektdotnet2.Models;

namespace projektdotnet2.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options) { }
        public virtual DbSet<Product> Products { get; set; }
    }
}

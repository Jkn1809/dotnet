﻿namespace projektdotnet2.Models
{
    public class Product
    {
        public uint Id { get; set; }
        public string? Nazwa { get; set; }
        public string? Gatunek { get; set; }
        public string? Serwis { get; set; }
        public int Rok { get; set; }
    }
}

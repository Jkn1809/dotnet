﻿$(document).ready(function () {
    $('#mojaTabela').DataTable({
        "scrollY": "450px",
        "scrollCollapse": true,
        "paging": true
    });
});